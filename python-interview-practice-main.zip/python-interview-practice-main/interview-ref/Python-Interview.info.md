### 1.  What are local variables and global variables in Python?

**Global Variables:**
* Variables declared outside a function or in a global space are called global variables.
* These variables can be accessed by any function in the program.

**Local Variables:**
* Any variable declared inside a function is known as a local variable.
* This variable is present in the local space and not in the global space.


### 2. When to use a tuple vs list vs dictionary in Python?

* Use a tuple to store a sequence of items that will not change.
* Use a list to store a sequence of items that may change.
* Use a dictionary when you want to associate pairs of two items

### 3. Explain some benefits of Python EARLY

* Python is a dynamic-typed language. It means that you don’t need to mention the data type of variables during their declaration.
* Python supports object-orientated programming as you can define classes along with the composition and inheritance.
* Functions in Python are like first-class objects. It suggests you can assign them to variables, return from other methods and pass them     as arguments.
* Developing using Python is quick but running it is often slower than compiled languages.
* Python has several usages like web-based applications, test automation, data modeling, big data analytics, and much more.

### 4.What is Lambda Functions in Python? 

* A Lambda Function is a small anonymous function.
* A lambda function can take any number of arguments, but can only have one expression.

Consider:
```ruby

  x = lambda a : a + 10
  print(x(5)) # Output: 15

```

### 5.How do I modify a string in python? 

* You can’t because strings are immutable in python.
* In most situations, you should simply construct a new string from the various parts you want to assemble it from.
* Work with them as lists; turn them into strings only when needed.

```ruby

>>> s = list("Hello zorld")
>>> s
['H', 'e', 'l', 'l', 'o', ' ', 'z', 'o', 'r', 'l', 'd']
>>> s[6] = 'W'
>>> s
['H', 'e', 'l', 'l', 'o', ' ', 'W', 'o', 'r', 'l', 'd']
>>> "".join(s)
'Hello World'

```

### 6.What is Negative Index in Python? 

* The actual index position starts from left to right .But here index position starts from right to left.

                          (or)

* Negative numbers mean that you count from the right instead of the left.
* So, list[-1] refers to the last element, list[-2] is the second-last, and so on.


### 7. How the string does get converted to a number? 

* To convert the string into a number the **built-in functions are used like int() constructor**.It is a data type that is used like int (‘1’) == 1.
* float() is also used to show the number in the format as float(‘1’) = 1.
* The number by default are interpreted as decimal and if it is represented by int(‘0x1’) then it gives an error as ValueError. In this     the int(string,base) function takes the parameter to convert string to number in this the process will be like int(‘0x1’,16) == 16. If   the base parameter is defined as 0 then it is indicated by an octal and 0x indicates it as hexadecimal number.
* There is function eval() that can be used to convert string into number but it is a bit slower and present many security risks

### 8. What is docstring in Python? 

* A documentation string or docstring is a multiline string used to document a specific code segment.
* The docstring should describe what the function or method does.

### 9. Does Python have a switch-case statement? 

* In Python before 3.10, we do not have a switch-case statement.
* Here, you may write a switch function to use. Else, you may use a set of if-elif-else statements.
* To implement a function for this, we may use a dictionary.

```ruby

def switch_demo(argument):
    switcher = {
        1: "January",
        2: "February",
        3: "March",
        4: "April",
        5: "May",
        6: "June",
        7: "July",
        8: "August",
        9: "September",
        10: "October",
        11: "November",
        12: "December"
    }
    print switcher.get(argument, "Invalid month")
    
    
```
    
* Python 3.10 (2021) introduced the match-case a statement that provides a first-class implementation of a "switch" for Python. For 
  Example:

### For example:

``` ruby

def f(x):
    match x:
        case 'a':
            return 1
        case 'b':
            return 2
            
```
* The match-case statement is considerably more powerful than this simple example.

### 10. What are descriptors ? 

* Descriptors were introduced to Python way back in version 2.2. They provide the developer with the ability to add managed attributes to objects. The methods needed to create a **descriptor are __get__, __set__ and __delete__.** If you define any of these methods, then you have created a descriptor.

* get the values from attribute,
* set the values to attribute,
* delete an attribute 

* Descriptors power a lot of the magic of Python’s internals. They are what make properties, methods and even the super function work. They are also used to implement the new style classes that were also introduced in Python 2.2.

### 11. What is the function of self? 

* **Self is a variable that represents the instance of the object to itself**. In most object-oriented programming languages, this is passed to the methods as a hidden parameter that is defined by an object. But, in python, it is declared and passed explicitly. It is the first argument that gets created in the instance of the class A and the parameters to the methods are passed automatically. It refers to a separate instance of the variable for individual objects.

* Let's say you have a class ClassA which contains a method methodA defined as:
```ruby

def methodA(self, arg1, arg2): #do something
and ObjectA is an instance of this class.

```

* Now when ObjectA.methodA(arg1, arg2) is called, python internally converts it for you as:

```ruby

ClassA.methodA(ObjectA, arg1, arg2)

```
* The self variable refers to the object itself.

### 12.What does an x = y or z assignment do in Python? 

```ruby

x = a or b

```
* If bool(a) returns False, then x is assigned the value of b.

### 13. What does this stuff mean: *args, **kwargs? Why would we use it? 

*  Use *args when we aren't sure how many arguments are going to be passed to a function, or if we want to pass a stored list or tuple of   arguments to a function.
```ruby

>>> def print_everything(*args):
        for count, thing in enumerate(args):
...         print( '{0}. {1}'.format(count, thing))
...
>>> print_everything('apple', 'banana', 'cabbage')
0. apple
1. banana
2. cabbage

```
* ** **kwargs is used when we don't know how many keyword arguments will be passed to a function**, or it can be used to pass the values of a dictionary as keyword arguments.

```ruby

>>> def table_things(**kwargs):
...     for name, value in kwargs.items():
...         print( '{0} = {1}'.format(name, value))
...
>>> table_things(apple = 'fruit', cabbage = 'vegetable')
cabbage = vegetable
apple = fruit

```

### 14.How can I create a copy of an object in Python? 

* **To get a fully independent copy** (deep copy) of an object you can use the copy.deepcopy() function. Deep copies are recursive copies of   each interior object.
* For shallow copy use copy.copy(). Shallow copies are just copies of the outermost container. it is dependent one.

### 15.What are with statment in Python ? 

* when ever we use with statement no need to close the file explicitly


```ruby

with open("foo.txt") as foo_file:
    data = foo_file.read()
    
        OR

from contextlib import nested
with nested(A(), B(), C()) as(X, Y, Z):
    do_something()

        OR (Python 3.1)

with open('data') as input_file, open('result', 'w') as output_file:
    for line in input_file:
        output_file.write(parse(line))
        
        OR

lock = threading.Lock()
with lock: #Critical section of code

```

### 16. What are the Dunder/Magic/Special methods in Python? 

* Dunder (derived from double underscore) methods are special/magic predefined methods in Python, with names that **start and end with a     double underscore. **There's nothing really magical about them. Examples of these include:

* __init__ - constructor
* __str__, __repr__ - object representation (casting to string, printing)
* __len__, __next__... - generators
* __enter__, __exit__ - context managers
* __eq__, __lt__, __gt__ - operator overloading

### 17. What is the difference between range and xrange? How has this changed over time? 

* xrange returns the xrange object while range returns the list, and uses the same memory and no matter what the range size is.
For the most part, xrange and range are the exact same in terms of functionality. They both provide a way to generate a list of integers for you to use, however you please.
* The only difference is that range returns a Python list object and x range returns an xrange object. This means that xrange doesn’t actually generate a static list at run-time as range does. It creates the values as you need them with a special technique called yielding. This technique is used with a type of object known as generators. That means that if you have a really gigantic range you’d like to generate a list for, say one billion, xrange is the function to use.
* This is especially true if you have a really memory-sensitive system such as a cell phone that you are working with, as range will use as much memory as it can to create your array of integers, which can result in a Memory Error and crash your program. It’s a memory-hungry beast.

### 18. What is introspection/reflection and does Python support it? 

* Introspection is the**ability to examine an object at runtime**. Python has a dir() the function that supports examining the attributes of an object, type() to check the object type, isinstance(), etc.

* While introspection is a passive examination of the objects, reflection is a more powerful tool where we could modify objects at runtime and access them dynamically. E.g.

**setattr() adds or modifies an object's attribute;
getattr() gets the value of an attribute of an object.**
* It can even invoke functions dynamically:
```ruby

getattr(my_obj, "my_func_name")()

```

### 19.  How to use Slicing in Python? 

* It's pretty simple really:
```ruby

a[start:stop]  # items start through stop-1
a[start:]      # items start through the rest of the array
a[:stop]       # items from the beginning through stop-1
a[:]           # a copy of the whole array

```
* There is also the step value, which can be used with any of the above:

* a[start:stop:step] # start through not past stop, by step
* The key point to remember is that the :stop the value represents the first value that is not in the selected slice. So, the difference   between stop and start is the number of elements selected (if step is 1, the default).

* The ASCII art diagram is helpful too for remembering how slices work:

```ruby

 +---+---+---+---+---+---+
 | P | y | t | h | o | n |
 +---+---+---+---+---+---+
 0   1   2   3   4   5   6
-6  -5  -4  -3  -2  -1

```
* Slicing built-in types return a copy but that's not universal.

### 20. How to make a flat list out of list of lists? 

* Given a list of lists l consider:

* flat list means create a nested list

```ruby 

flat_list = []
for sublist in l:
    for item in sublist:
        flat_list.append(item)
        
```
* Or using the lambda function:

```ruby

flatten = lambda l: [item for sublist in l for item in sublist]
print(flatten([[1],[2],[3],[4,5]]))
# Output: [1, 2, 3, 4, 5]   


```
### 21.What is the most efficient way to concatenate many strings together?

* str and bytes objects are immutable, therefore concatenating many strings together is inefficient as each concatenation creates a new     object.
* In the general case, the total runtime cost is quadratic in the total string length.

* To accumulate many str objects, I would recommend placing them into a list and**call str.join()at the end:**
```ruby

chunks = []
for s in my_strings:
    chunks.append(s)
result = ''.join(chunks)

```
### 22. What are Virtualenvs ? 

* A virtualenv is what Python developers call an isolated environment for **development, running, debugging Python code**.
* It is used to isolate a Python interpreter together with a set of libraries and settings.
* Together with pip, it **allows developing, deploy and run of multiple applications on a single host**, each with its own version of the       Python interpreter, and a separate set of libraries.

### 23. What is Pickling and Unpickling? 

* The pickle the module implements a fundamental, but powerful algorithm for serializing and de-serializing a Python object structure.

* Pickling - is the process whereby a **Python object hierarchy is converted into a byte stream,**
  Unpickling - is the inverse operation, **whereby a byte stream is converted back into an object hierarchy.**

```ruby

>>> import random 
>>> import pickle 
>>> num_list = [random.random() for _ in range(10_000)] 
>>> len(num_list) 
10000 
>>> num_list[:3] 
[0.4877162104023087, 0.23514961430367143, 0.683895941250586] 
>>> with open('nums.out', 'wb') as f: 
...     pickle.dump(num_list, f) 
... 
>>> with open('nums.out', 'rb') as f: 
...     copy_of_nums_list = pickle.load(f) 
... 
>>> copy_of_nums_list[:3] 
[0.4877162104023087, 0.23514961430367143, 0.683895941250586] 
>>> num_list == copy_of_nums_list 
True 

```
### 24. What is a None value in Python? 

* None is just a value that commonly is used to signify 'empty', or 'no value here.
* If you write a function, and that function doesn't use an explicit return statement, None is returned instead, for example.

* Another example is to use None default values. it is good programming practice to not use mutable objects as default values. Instead,     use None it as the default value and inside the function, check if the parameter is None and create a new list/dictionary/whatever if     it is.

Consider:

```ruby 

def foo(mydict=None):
    if mydict is None:
        mydict = {}  # create a new dict for local namespace

```
### 25. What is Monkey Patching 

* In Python, the term monkey patch only refers to dynamic modifications of a class or module at runtime, which means a monkey patch is a   piece of Python code that extends or modifies other code at runtime.
* Monkey patching can only be done in dynamic languages, of which python is a good example. In Monkey patching, we reopen the existing classes or methods in class at runtime and alter the behavior, which should be used cautiously, or you should use it only when you really need to. As Python is a dynamic programming language, Classes are mutable so you can reopen them and modify or even replace them.

* For example:
```ruby

import datetime
datetime.datetime.now = lambda: datetime.datetime(2012, 12, 12)

```
* Most of the time it's a pretty terrible idea - it is usually best if things act in a well-defined way. One reason to monkey patch would   be in testing. The mock package is very useful to this end.

### 26. Explain Decorators in Python? 

* In Python, functions are the first-class objects, which means that:

* Functions are objects; they can be referenced to, passed to a variable, and returned from other functions as well.
  Functions can be defined inside another function and can also be passed as arguments to another function.

Now:

* Decorators allow us to wrap another function in order to extend the behavior of the wrapped function, without permanently modifying it.
  Decorators are a very powerful and useful tool in Python since it allows programmers to modify the behavior of a function or class.
```ruby

@gfg_decorator
def hello_decorator(): 
    print("Gfg") 
  
'''Above code is equivalent to:
  
def hello_decorator(): 
    print("Gfg") 
      
hello_decorator = gfg_decorator(hello_decorator)'''

                    (or)
                    
                    
def div(a,b):
    print(a/b)

def smart_div(func):
    def inner(a,b):
        if a<b:
            a,b = b,a
        return func(a,b)
    return inner
div = smart_div(div)

div (2,8)









 
```
### 27.Explain the difference between lists and tuples ? 

* The key difference is that tuples are immutable. This means that you cannot change the values in a tuple once you have created it.
* If you're going to need to change the values using a List.
* Apart from tuples being immutable, there is also a semantic distinction that should guide their usage. Tuples are heterogeneous data     structures (i.e., their entries have different meanings), while lists are homogeneous sequences. Tuples have structure, and lists have   been ordered.

* One example of a tuple is pairs of the page and line number to reference locations in a book, e.g.:

```ruby

my_location = (42, 11)  # page number, line number

```
* You can then use this as a key in a dictionary to store notes on locations. A list on the other hand could be used to store multiple     locations. Naturally one might want to add or remove locations from the list, so it makes sense that lists are mutable. On the other     hand, it doesn't make sense to add or remove items from an existing location - hence tuples are immutable.

### 28.Why would you use the pass statement ? 

* Python has the syntactical requirement that code blocks cannot be empty. Empty code blocks are however useful in a variety of different   contexts, for example, if you are designing a new class with some methods that you don't want to implement:
```ruby

class MyClass(object):
    def meth_a(self):
        pass

    def meth_b(self):
        print "I'm meth_b"

```
* If you were to leave out the pass, the code wouldn't run and you'll get an error:
```ruby

IndentationError: expected an indented block
```
### Other examples when we could use pass:

* Ignoring (all or) a certain type of Exception
* Deriving an exception class that does not add new behavior
* Testing that code runs properly for a few test values, without caring about the results

### 29.What's the difference between the list methods append() and extend()? 

* append adds an element to a list, and
* extend concatenates the first list with another list (or another iterable, not necessarily a list).

* Consider:

```ruby
x = [1, 2, 3]
x.append([4, 5])
print (x)
# [1, 2, 3, [4, 5]]

x = [1, 2, 3]
x.extend([4, 5])
print (x)
# [1, 2, 3, 4, 5]
 
```

### 30.How to define static methods in python ?

* The static keyword is used to construct methods that will exist regardless of whether or not any         instances of the class are generated. Any method that uses the static keyword is referred to as a         static method.





* To define a static method, you use the @staticmethod decorator:

* class className: @staticmethod def static_method_name(param_list): pass
```ruby

Code language: Python (python)

```
* To call a static method, you use this syntax:
```ruby
className.static_method_name()
```

### 31.How does Python memory management work? 

* Python - like C#, Java, and many other languages -- uses garbage collection rather than manual memory management. You just freely         create objects and the language's memory manager periodically (or when you specifically direct it to) looks for any objects that are no   longer referenced by your program.

* If you want to hold on to an object, just hold a reference to it. If you want the object to be freed (eventually) remove any references to it.

```ruby

def foo(names):
  for name in names:
    print name

foo(["Eric", "Ernie", "Bert"])
foo(["Guthtrie", "Eddie", "Al"])

```
* Each of these calls to foo creates a Python list object initialized with three values. For the duration of the foo call they are         referenced by the variable names, but as soon as that function exits no variable is holding a reference to them and they are fair game   for the garbage collector to delete.


### 32.What is a Callable? 

* A callable is anything that can be called.
* A callable object allows you to use round parenthesis ( ) and eventually pass some parameters, just like functions.
Every time you define a function python creates a callable object. In the example, you could define the function func in these ways (it's the same):

```ruby

class a(object):
    def __call__(self, *args):
        print 'Hello'

func = a()

# or ... 
def func(*args):
    print 'Hello'
    
```

### 33. Why are default values shared between objects? 

* It is often expected that a function call creates new objects for default values. This is not what happens. Default values are created   exactly once, when the function is defined. If that object is changed, like the dictionary in this example, subsequent calls to the       function will refer to this changed object.

* Consider:

```ruby

def foo(mydict={}):  # Danger: shared reference to one dict for all calls
    ... compute something ...
    mydict[key] = value
    return mydict

```

* The first time you call this function, mydict contains a single item. The second time, mydict contains two items because when             foo()begins executing, mydict starts out with an item already in it.

### 34. How to make a chain of function decorators ? 

* Code:

```ruby

from functools import wraps

def makebold(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        return "<b>" + fn(*args, **kwargs) + "</b>"
    return wrapped

def makeitalic(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        return "<i>" + fn(*args, **kwargs) + "</i>"
    return wrapped

@makebold
@makeitalic
def hello():
    return "hello world"

@makebold
@makeitalic
def log(s):
    return s

print hello()        # returns "<b><i>hello world</i></b>"
print hello.__name__ # with functools.wraps() this returns "hello"
print log('hello')   # returns "<b><i>hello</i></b>"
 

```

### 35. What is the difference between deep and shallow copy ? 

* Shallow copy is used when a new instance type gets created and it keeps the values that are copied in the new instance. Whereas, a deep   copy is used to store the values that are already copied.
* Shallow copy is used to copy the reference pointers just like it copies the values. These references point to the original objects and   the changes made in any member of the class will also affect the original copy of it. Whereas, deep copy doesn’t copy the reference       pointers to the objects. Deep copy makes the reference to an object and the new object that is pointed by some other object gets         stored. The changes made in the original copy won’t affect any other copy that uses the object.
* Shallow copy allows faster execution of the program and it depends on the size of the data that is used. Whereas, deep copy makes it     slower due to making certain copies for each object that is been called.

### 36. What is the purpose of the single underscore _ variable in Python? 

* _ has 4 main conventional uses in Python:

* To hold the result of the last executed expression(/statement) in an interactive interpreter session. This precedent was set by the       standard CPython interpreter, and other interpreters have followed suit
  For translation lookup in i18n (see the gettext documentation for example), as in code like: raise forms.ValidationError(_("Please       enter a correct username"))
* As a general-purpose "throwaway" variable name to indicate that part of a function result is being deliberately ignored (Conceptually,   it is being discarded.), as in code like: label, has_label, _ = text.partition(':').
* As part of a function definition (using either def or lambda), where the signature is fixed (e.g. by a callback or parent class API),     but this particular function implementation doesn't need all of the parameters, as in code like: callback = lambda _: True

### 37.Explain how you reverse a generator? 

* You cannot reverse a generator in any generic way except by casting it to a sequence and creating an iterator from that. Later terms of a generator cannot necessarily be known until the earlier ones have been calculated.

* Even worse, you can't know if your generator will ever hit a StopIteration exception until you hit it, so there's no way to know what there will even be a first term in your sequence.

* The best you could do would be to write a reversed_iterator function:

```ruby

def reversed_iterator(iter):
    return reversed(list(iter))
    
    
```
### 38.Can you explain Closures (as they relate to Python)? 

* Objects are data with methods attached, closures are functions with data attached. The method of binding data to a function without       actually passing them as parameters is called closure.

```ruby

def make_counter():
    i = 0
    def counter(): # counter() is a closure
        nonlocal i
        i += 1
        return i
    return counter

c1 = make_counter()
c2 = make_counter()

print (c1(), c1(), c2(), c2())
# -> 1 2 1 2

```

### 39.What is MRO in Python? How does it work? 

* Method Resolution Order (MRO) it denotes the way a programming language resolves a method or attribute. Python supports classes           inheriting from other classes. The class being inherited is called the Parent or Superclass, while the class that inherits is called     the Child or Subclass.

* In Python, method resolution order defines the order in which the base classes are searched when executing a method. First, the method   or attribute is searched within a class and then it follows the order we specified while inheriting. This order is also called           Linearization of a class and set of rules are called MRO (Method Resolution Order). While inheriting from another class, the             interpreter needs a way to resolve the methods that are being called via an instance. Thus we need the method resolution order.

* Python resolves method and attribute lookups using the C3 linearisation of the class and its parents. The C3 linearisation is neither     depth-first nor breadth-first in complex multiple inheritance hierarchies.

### 40.Is it a good idea to use multi-thread to speed your Python code? 

* Python doesn't allow multi-threading in the truest sense of the word. It has a multi-threading package but if you want to multi-thread   to speed your code up, then it's usually not a good idea to use it.

* Python has a construct called the Global Interpreter Lock (GIL). The GIL makes sure that only one of your 'threads' can execute at any   one time. A thread acquires the GIL, does a little work, then passes the GIL onto the next thread. This happens very quickly so to the   human eye it may seem like your threads are executing in parallel, but they are really just taking turns using the same CPU core. All     this GIL passing adds overhead to execution.

### 41. Explain the difference between @staticmethod and @classmethod? 

* A staticmethod is a method that knows nothing about the class or the instance it was called on. It just gets the arguments that were     passed, no implicit first argument. Its definition is immutable via inheritance.

```ruby

class C:
    @staticmethod
    def f(arg1, arg2, ...): ... 
```

* A classmethod, on the other hand, is a method that gets passed the class it was called on, or the class of the instance it was called     on, as the first argument. Its definition follows Sub class, not Parent class, via inheritance.

```ruby

class C:
   @classmethod
   def f(cls, arg1, arg2, ...): ...  

```
* If your method accesses other variables/methods in your class then use @classmethod.

                                                  (OR)
                                
**Class methods:** Used to access or modify the state of the class. if we use only class variables, we should declare such methods as a class method.


**Static methods:** A static method is a general utility method that performs a task in isolation. Inside this method, we don’t use instance or class variable because this static method doesn’t take any parameters like self and cls.




### 42.What is GIL? 

* Python has a construct called the Global Interpreter Lock (GIL).

* The GIL makes sure that only one of your threads can execute at any one time. A thread acquires the GIL, does a little work, then         passes the GIL onto the next thread. This happens very quickly so to the human eye it may seem like your threads are executing in         parallel, but they are really just taking turns using the same CPU core. All this GIL passing adds overhead to execution.


### 43.Why would you use metaclasses? 

* The term metaprogramming refers to the potential for a program to have knowledge of or manipulate         itself. Python supports a form of metaprogramming for classes called metaclasses.



* The main use case for a metaclass is creating an API. A typical example of this is the Django ORM.
* It allows you to define something like this:

```ruby

class Person(models.Model):
    name = models.CharField(max_length=30)
    age = models.IntegerField()

```
* And if you do this:


```ruby

guy = Person(name='bob', age='35')
print(guy.age)

```
* It won't return an IntegerField object. It will return an int, and can even take it directly from the database.

* This is possible because models.Model defines __metaclass__and it uses some magic that will turn the Person you just defined with simple statements into a complex hook to a database field.

* Django makes something complex look simple by exposing a simple API and using metaclasses, recreating code from this API to do the real   job behind the scenes.


### 44.Describe Python's Garbage Collection mechanism in brief .

* It is a built in feature in python 
* It is used for deleted to un_nessery objects from a list automatically
* Here we have two parts yougher genaration,older genaration
* yougher is used to strore the used objects are stored
* older is used to store circle references 
* un nessasary items are deleted perminantly


* A lot can be said here. There are a few main points that you should mention:

* Python maintains a count of the number of references to each object in memory. If a reference count goes to zero then the associated     object is no longer live and the memory allocated to that object can be freed up for something else
* occasionally things called "reference cycles" happen. The garbage collector periodically looks for these and cleans them up. An example   would be if you have two objects o1 and o2 such that o1.x == o2 and o2.x == o1. If o1 and o2 are not referenced by anything else then     they shouldn't be live. But each of them has a reference count of 1.
* Certain heuristics are used to speed up garbage collection. For example, recently created objects are more likely to be dead. As         objects are created, the garbage collector assigns them to generations. Each object gets one generation, and younger generations are     dealt with first.


### 45.Why isn't all memory freed when Python exits? 

* **Objects referenced from the global namespaces of Python modules are not always deallocated when Python exits.** This may happen if there are circular references. There are also certain bits of memory that are allocated by the C library that are impossible to free (e.g. a tool like Purify will complain about these). Python is, however, aggressive about cleaning up memory on exit and does try to destroy every single object.

* If you want to force Python to delete certain things on deallocation, you can use the atexit module to register one or more exit         functions to handle those deletions.

### 46.How do I access a module written in Python from C? 

* You can get a pointer to the module object by calling PyImport_ImportModule:

```ruby

module = PyImport_ImportModule("mymodule");

```
* You can then access the module’s attributes (i.e. any name defined in the module) as follows:

```ruby

attr = PyObject_GetAttrString(module, "name");

```
* Calling PyObject_SetAttrString to assign to variables in the module also works.

### 47.How to read a very large file in Python? 

* All you need to do is use the file object as an iterator.

```ruby

for line in open("log.txt"):
    do_something_with(line)
```

* Even better is using context manager in recent Python versions.

```ruby

with open("log.txt") as fileobject:
    for line in fileobject:
        do_something_with(line)


```

* This will automatically close the file as well.

### 48.Is there any downside to the -O flag apart from missing on the built-in debugging information? 

* Many python modules assume docstrings are available, and would break if that optimization level is used, for instance at the company     where I work, raw SQL is placed in docstrings, and executed by way of function decorators (not even kidding).

* Somewhat less frequently, assert is used to perform logic functions, rather than merely declare the invariant expectations of a point     in code, and so any code like that would also break.

### 49. Explain all file processing modes supported in Python?
* Python has various file processing modes.

* There are majorly three modes for opening files:
**read-only mode , (r)
write-only mode and(w)
read-write mode (rw)**
* (Optional) For opening a text file using the above modes, we can also append ‘t’ with them as follows:
**read-only mode (rt)
write-only mode (wt)
read-write mode (rwt)**
* Similarly, a binary file can only be appropriately parsed and read by appending 'be with them as follows:
**read-only mode (RB)
write-only mode (wb)
read-write mode (rwb)**
* If you want to append the content in the files, we can also use the append mode (a):

* For text files, mode would be 'at'
* For binary files, it would be ‘ab’

### 50.Why isn’t all the memory deallocated after the end of execution of Python programs?

* When Python programs exit, especially those using Python modules with circular references to other objects or the objects referenced from the global namespaces are not always deallocated or freed.
* Since it is not possible to deallocate those portions of memory that the C library reserves.
* On exit, because of having its efficient cleanup mechanism, Python would try to deallocate every object.

### 51.What is PEP 8 and why is it important?
* PEP stands for Python Enhancement Proposal. A PEP is an official design document providing information to the Python community, or       describing a new feature for Python or its processes. PEP 8 is especially important since it documents the style guidelines for Python   Code. Apparently contributing to the Python open-source community requires you to follow these style guidelines sincerely and strictly.
 
### 52.  What is PYTHONPATH?

* PYTHONPATH has a role similar to PATH. This variable tells Python Interpreter where to locate the module files imported into a program.   It should include the Python source library directory and the directories containing Python source code. PYTHONPATH is sometimes preset   by Python Installer.


### 53.What are Python Modules?

* Files containing Python codes are referred to as Python Modules. This code can either be classes, functions, or variables and saves the   programmer time by providing the predefined functionalities when needed. It is a file with “.py” extension containing an executable       code.

* Commonly used built modules are listed below:

* os
* sys
* data time
* math
* random
* JSON

### 54.Explain Inheritance in Python with an example?

* As Python follows an object-oriented programming paradigm, classes in Python have the ability to inherit the properties of another class. This process is known as inheritance. Inheritance provides the code reusability feature. The class that is being inherited is called a superclass or the parent class, and the class that inherits the superclass is called a derived or child class. The following 

**types of inheritance are supported in Python:**

* Single inheritance: When a class inherits only one superclass
* Multiple inheritance: When a class inherits multiple superclasses
* Multilevel inheritance: When a class inherits a superclass, and then another class inherits this derived class forming a ‘parent,         child, and grandchild’ class structure
* Hierarchical inheritance: When one superclass is inherited by multiple derived classes


### 55.What is __init__ in Python?

* Equivalent to constructors in OOP terminology, __init__ is a reserved method in Python classes. The __init__ method is called             automatically whenever a new object is initiated. This method allocates memory to the new object as soon as it is created. This method   can also be used to initialize variables.

**Syntax**

```ruby

(for defining the __init__ method):
class Human:
# init method or constructor
def __init__(self, age):
self.age = age
# Sample Method
def say(self):
print('Hello, my age is', self.age)
h= Human(22)
h.say()

```

### Output:

```ruby

Hello, my age is 22


```

### 56.What are the common built-in data types in Python?

* Python supports the below-mentioned built-in data types:

**Immutable data types:**

* Number
* String
* Tuple
**Mutable data types:**

* List
* Dictionary
* set

### 57.Python is an interpreted language. Explain.

* An interpreted language is any programming language that executes its statements line by line. 
* Programs written in Python run directly from the source code, with no intermediary compilation step.

### 58.What are python namespaces?

* A Python namespace ensures that object names in a program are unique and can be used without any conflict. Python implements these namespaces as dictionaries with ‘name as key’ mapped to its respective ‘object as value’.

* Let’s explore some examples of namespaces:

* Local Namespace consists of local names inside a function. It is temporarily created for a function call and gets cleared once the       function returns.
* Global Namespace consists of names from various imported modules/packages that are being used in the ongoing project. It is created       once the package is imported into the script and survives till the execution of the script.
  Built-in Namespace consists of built-in functions of core Python and dedicated built-in names for various types of exceptions.
  
### 59.What is type conversion in Python?

* Python provides you with a much-needed functionality of converting one form of data type into the needed one and this is known as type conversion.

* Type Conversion is classified into types:

* 1.Implicit Type Conversion: In this form of Type conversion python interpreter helps in automatically converting the data type into another data type without any User involvement.

* 2.Explicit Type Conversion: In this  form of Type conversion the data  type inn changed into a required type by the user.

* Various Functions of explicit conversion are show below:

* int() –  function converts any data type into integer.
* float() –   function converts any data type into float.
* ord() – function returns an integer representing the Unicode character
* hex() –  function converts integers to hexadecimal strings.
* oct() –   function converts integer to octal strings.
* tuple() – function convert to a tuple.
* set() – function returns the type after converting to set.
* list() – function converts any data type to a list type.
* dict() – function is used to convert a tuple of order (key,value) into a dictionary.
* str() –  function used to convert integer into a string.
* complex(real,imag) – function used to convert real numbers to complex(real,imag) numbers.

### 60. Is indentation required in Python?

* Indentation in Python is compulsory and is part of its syntax.
* All programming languages have some way of defining the scope and extent of the block of codes. In Python, it is indentation.   Indentation provides better readability to the code, which is probably why Python has made it compulsory


### 61.What is the difference between Python Arrays and Lists?

* Lists and arrays both are used to store data, but the difference is that the List can any hold any data type while arrays can hold a single data type.

### Example:

```ruby

import array as arr
My_Array=arr.array(‘i’,[4,3,2,1])
My_list=[5,’abc’,1.20]
print(My_Array)
print(My_list)

```

**Output:**

```ruby

array(‘i’, [4, 3, 2, 1])

[5, ‘abc’, 1.2]

```

### 62.Write a program to print odd numbers in a List?

* We are using for loop to print odd numbers in a list

```ruby

list1 = [10, 21, 4, 45, 66, 93]  //list of numbers
 

for num in list1:

    if num % 2 != 0:

       print(num, end = ” “)
```

**Output:**
``` ruby

21 45 93

```

### 63.Name some standard Python errors.

* Some standard errors are –

* TypeError
* ValueError
* NameError
* IOError
* IndexError
* KeyError
* We can use dir(__builtin__) to list all the errors.

### 64.What is the right way to transform a Python string into a list?

* In Python, strings are just like lists. And it is easy to convert a string into the list. Simply by passing the string as an argument to the list would result in a string-to-list conversion.

```ruby

list("I am learning Python.")

```

**Program Output**

```ruby

Python 2.7.10 (default, Jul 14 2015, 19:46:27)
[GCC 4.8.2] on linux

=> ['I', ' ', 'a', 'm', ' ', 'l', 'e', 'a', 'r', 'n', 'i', 'n', 'g', ' ', 'P', 'y', 't', 'h', 'o', 'n', '.']

```

### 65.What are global, protected and private attributes in Python?

* Global variables are public variables that are defined in the global scope. To use the variable in the global scope inside a function, we use the global keyword.
* Protected attributes are attributes defined with an underscore prefixed to their identifier eg. _sara. They can still be accessed and modified from outside the class they are defined in but a responsible developer should refrain from doing so.
* Private attributes are attributes with double underscore prefixed to their identifier eg. __ansh. They cannot be accessed or modified from the outside directly and will result in an AttributeError if such an attempt is made.

### 66. What is break, continue and pass in Python?

* Break	The break statement terminates the loop immediately and the control flows to the statement after the body of the loop.
* Continue	The continue statement terminates the current iteration of the statement, skips the rest of the code in the current iteration and the control flows to the next iteration of the loop.
* Pass	As explained above, the pass keyword in Python is generally used to fill up empty blocks and is similar to an empty statement represented by a semi-colon in languages such as Java, C++, Javascript, etc.

```ruby

pat = [1, 3, 2, 1, 2, 3, 1, 0, 1, 3]
for p in pat:
   pass
   if (p == 0):
       current = p
       break
   elif (p % 2 == 0):
       continue
   print(p)    # output => 1 3 1 3 1
print(current)    # output => 0


```

### 67.What is docstring in Python?

* Documentation string or docstring is a multiline string used to document a specific code segment.
* The docstring should describe what the function or method does.

### 68.Explain split() and join() functions in Python?
* You can use split() function to split a string based on a delimiter to a list of strings.
* You can use join() function to join a list of strings based on a delimiter to give a single string.

```ruby

string = "This is a string."
string_list = string.split(' ') #delimiter is ‘space’ character or ‘ ‘
print(string_list) #output: ['This', 'is', 'a', 'string.']
print(' '.join(string_list)) #output: This is a string.


```

### 68.### 44.Generator-Function :

* A generator-function is defined like a normal function, but whenever it needs to generate a value, it does so with the yield keyword rather than return. If the body of a def contains yield, the function automatically becomes a generator function.

#### A generator function that yields 1 for first time,
#### 2 second time and 3 third time
def simpleGeneratorFun():
    yield 1            
    yield 2            
    yield 3            
   
#### Driver code to check above generator function
for value in simpleGeneratorFun(): 
    print(value)


**Output :**

1
2
3


### 69.Session:
* A Session establishes and maintains all conversations between your program and the databases
* It calls the object's connect() method, and assigns the result to the object's session data member.

* If you examine the connect() method, you'll see that it establishes and returns an ssh connection (or None if the connection cannot be established).

### 70.What are cookies Python? What is this and what is it for? 
* cookies.py is a Python module for working with HTTP cookies: parsing and rendering 'Cookie:' request headers and 'Set-Cookie:' response headers, and exposing a convenient API for creating and modifying cookies. It can be used as a replacement of Python's Cookie.py

* The Cookie module defines classes for abstracting the concept of cookies, an HTTP state management mechanism. It supports both simple string-only cookies, and provides an abstraction for having any serializable data-type as cookie value.

































