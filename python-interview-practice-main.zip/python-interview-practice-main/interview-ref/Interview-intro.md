* I am MANOHAR .Now currently i am working in **Evry india pvt Lmtd**, having arround 2.5 years of experience  as a python developer in this duration working on technologies  like python,django,Html,css,javascript,rest API ,SQL andJenkins.

* currently working for fedbid client.Now it was acquired by unison market place.

* Comming to the my current project back office application is a EPS that is known as the Escrow Payment System .In this there are various modules like Organization Module,Bank Module ,Order Module,ACH(Automated cleaning House) and Admin Module.

* For deployment we are using Jenkins (CICD) continous Intigration continuos deployement.

* In this I worked on Org.module and Admin module.

### Benifits of EPS:

* **For Seller:** 

* Reduce credit risks,Reduces bad debits ,Compress days sale outstanding

* **For buyers**

* Protection is provided by the ability to inspect the goods prior to disbursement of payment to the seller,Reduces accounts payable since payment is made upfront


**Organization Module**

* In this Org module we do have Organization details , officer details,Point of contact details,Org hierachy details ,Org history.

##### Point of contact
* First Name...............
* Last Name................
* Title....................
* Email....................
* Fax......................
* Phone....................

##### Officer KYC
* First Name
* Last Name

##### Add Comment:
* To comment anything

##### Organizatin History
* Org 1
* Org 2
* Org 3
* Org 4 and so on.............

**Admin module**

* In this admin module we do have the Admin Dashboard.
* Admin could see locked orgs information.

* we do have a employee dash board . In the employee dash board ,In that we do have the list of information and their status 

1. Add Employee
2. Update Employee































