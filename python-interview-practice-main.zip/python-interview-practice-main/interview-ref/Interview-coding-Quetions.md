### Many To One : 

```ruby

from django.db import models

class Album(models.Model):
title = models.CharField(max_length = 100)
artist = models.CharField(max_length = 100)

class Song(models.Model):
title = models.CharField(max_length = 100)
album = models.ForeignKey(Album, on_delete = models.CASCADE)

```

### Many To Many :


```ruby

from django.db import models

class Author(models.Model):
name = models.CharField(max_length = 100)
desc = models.TextField(max_length = 300)

class Book(models.Model):
title = models.CharField(max_length = 100)
desc = models.TextField(max_length = 300)
authors = models.ManyToManyField(Author)

```


### One To One:


```ruby

from django.db import models

class Vehicle(models.Model):
reg_no = models.IntegerField()
owner = models.CharField(max_length = 100)

class Car(models.Model):
vehicle = models.OneToOneField(Vehicle, 
on_delete = models.CASCADE, primary_key = True)
car_model = models.CharField(max_length = 100) 


```	



### ForeignKey:

```ruby

class Author(models.Model):
name = models.CharField(max_length=512)
class Book(models.Model):
title = models.CharField(max_length=512)
author = models.ForeignKey(Author, on_delete=models.CASCADE)


```


### Recursion Example

```ruby

def tri_recursion(k):
if(k>0):
result = k+tri_recursion(k-1)
print(result)
else:
result = 0
return result

print("\n\nRecursion Example Results")
tri_recursion(6)


```


### Decorators:


```ruby


@gfg_decorator
def hello_decorator(): 
print("Gfg") 

'''Above code is equivalent to:

def hello_decorator(): 
print("Gfg") 

hello_decorator = gfg_decorator(hello_decorator)'''

(or)


def div(a,b):
print(a/b)

def smart_div(func):
def inner(a,b):
if a<b:
a,b = b,a
return func(a,b)
return inner
div = smart_div(div)

div (2,8)



( or )


def smart_div(func):
    def inner(a,b):
       if a<b:
        a,b = b,a
        return func(a,b)
    return inner
@smart_div
def div(a,b):
 print(a/b)
div (2,8)


```

### Models:


```ruby

from django.db import models  

class Employee(models.Model):  
first_name = models.CharField(max_length=30)  
last_name = models.CharField(max_length=30) 


```
### Views:

* Inside of application views.py

```ruby

from django.shortcuts import render
from django.http import HttpResponse

def index(request):
return HttpResponse("Hello world!")
```
* inside of application urls.py

```ruby


from django.urls import path
from . import views

urlpatterns = [
path('', views.index, name='index'),
]

* Inside of project Urls.py

```ruby



from django.contrib import admin
from django.urls import include, path

urlpatterns = [
path('members/', include('members.urls')),
path('admin/', admin.site.urls),
]


```

* inside of application we create a template that to inside create a new file

```ruby

<!DOCTYPE html>
<html>
<body>

<h1>Hello World!</h1>
<p>Welcome to my first Django project!</p>

</body>
</html>

```

* inside of application view modification


```ruby

from django.http import HttpResponse
from django.template import loader

def index(request):
template = loader.get_template('myfirst.html')
return HttpResponse(template.render())

```



* inside settings.py in project we have to add name with app

```ruby

INSTALLED_APPS = [
'django.contrib.admin',
'django.contrib.auth',
'django.contrib.contenttypes',
'django.contrib.sessions',
'django.contrib.messages',
'django.contrib.staticfiles',
'members.apps.MembersConfig'
]

```


### Printing highest number in Array:

```ruby

Numbers = [90,78,34,50,100,99]
higest_number = 0
for number in Numbers:
if number > higest_number:
higest_number = number

print(higest_number)



(or)	


Numbers = [11,33,44,4,5,4,3,3,2333]
max_number = 0
for i in Numbers:
while i > max_number:
max_number = i

print(max_number)	



(or)


lis = [2, 4, 1, 5, 3, 8, 9]
lis.sort()
print("max = ", lis[-1])



```

### print N largest in List


```




def N_max_elements(list, N):
    result_list = []

    for i in range(0, N):
        maximum = 0

        for j in range(len(list)):
            if list[j] > maximum:
                maximum = list[j]

        list.remove(maximum)
        result_list.append(maximum)

    return result_list


# test
list1 = [2, 6, 41, 85, 0, 3, 7, 6, 10]
N = 2

print(N, "max elements in ", list1)

# Calling and printing the function
print(N_max_elements(list1, N))








```










### printing max and min Value 

```ruby


lis = [2, 4,1, 5,3,8,9] 
lis.sort() 
print("max = ", lis[-1], " min = ", lis[0]) 



```


### To print min value::

```ruby



#Initialize array     
arr = [25, 11, 7, 75, 56];     

#Initialize min with the first element of the array.    

min = arr[0];    

#Loop through the array    
for i in range(0, len(arr)):    
#Compare elements of array with min    
if(arr[i] < min):    
min = arr[i];    

print("Smallest element present in given array: " + str(min));    



#### Output:

Smallest element present in given array: 7




(or)



Numbers = [90,78,34,50,100,99,1234]
min_number = 100
for number in Numbers:
if number < min_number:
min_number = number

print(min_number)








```
### Sorting an elements ascending order



```ruby


list = [1, 3, 123, 1, 42, 123] # RANDOM NUMBERS
list.sort()
print(list)





(or)







my_list = [-15, -26, 15, 1, 23, -64, 23, 76]
new_list = []

while my_list:
min = my_list[0]  
for x in my_list: 
if x < min:
min = x
new_list.append(min)
my_list.remove(min)    

print(new_list)


```

### Descending order

```ruby


NumList = [12,45,87,49,56,46]
print("\nElement Before Sorting is: ", NumList)
NumList.sort()
NumList.reverse()
print("\nElement After Sorting List in Descending Order is: \n", NumList)



(or)




list = [1,2,3,4,5,6,7]
list.sort(reverse = True)
print(list)



```

### List of Average numbers:


```ruby


n=int(input("Enter the number of elements to be inserted: "))
a=[]
for i in range(0,n):
 elem=int(input("Enter element: "))
a.append(elem)
avg=sum(a)/n
print("Average of elements in the list",round(avg,2))




```

### Dictonary:


```ruby

cities = {'San Francisco': 'US', 'London':'UK',
        'Manchester':'UK', 'Paris':'France',
        'Los Angeles':'US', 'Seoul':'Korea'}

# => {'US':['San Francisco', 'Los Angeles'], 'UK':[,], ...}

from collections import defaultdict
# using collections.defaultdict()
d1 = defaultdict(list) # initialize dict with list
for k,v in cities.items():
    d1[v].append(k)
print(f'd1 = {d1}')

# using dict.setdefault(key, default=None)
d2 = {}
for k,v in cities.items():
       d2.setdefault(v,[]).append(k)
print(f'd2 = {d2}')



```
### method overriding::
```ruby

class A:
    def display(self):
        print("this is class A")
        

 

class B:
    def display(self):
        print("this is class B")
        
class C(A, B):
    
    pass
    
c = C()

 

c.display()







```
### revese a Nested List::


```ruby 

my_list=[[1,2],[3,4],[5,6,7]]
for sub_list in my_list:
  sub_list.reverse()
print(my_list)


````

### STRINGS


### Length of a String::

```ruby

str = "geeks"
print(len(str))


(or)




def findLen(str):
    counter = 0   
    for i in str:
        counter += 1
    return counter
 
 
str = "geeks"
print(findLen(str))





```

### String Spliting and Join

```ruby

a = "The good peoples are goning to heaven"
c = a.split(" ")

print(c)

e = " ".join(c)
print(e)

```

### String word reversing and Joining 

```ruby


a = "The good peoples are goning to heaven"
c = a.split(" ")[::-1]

print(c)

e = " ".join(c)
print(e)

```

### String is a Palindrom are not?


```ruby

p = "24242"

def s(p):
    return p==p[::-1]

if s(p):

    print("its a palindrom")
else:
    print("its not a palindrom")
    
    
```


### LIST ::



### sum of list elements::

```ruby

arr = [12, 3, 4, 15]

print (sum(arr))

```

### Largest Numbers in List

```ruby


Numbers = [90,78,34,50,100,99]
higest_number = 0
for number in Numbers:
if number > higest_number:
higest_number = number

print(higest_number)


```
### Print Min value in a List

```ruby

Numbers = [90,78,34,50,100,99,1234]
min_number = 100
for number in Numbers:
if number < min_number:
min_number = number

print(min_number)

```


### N Largest Numbers in List

```ruby

def N_max_elements(list, N):
    result_list = []

    for i in range(0, N):
        maximum = 0

        for j in range(len(list)):
            if list[j] > maximum:
                maximum = list[j]

        list.remove(maximum)
        result_list.append(maximum)

    return result_list



list1 = [2, 6, 41, 85, 0, 3, 7, 6, 10]
N = 2

print(N, "max elements in ", list1)


print(N_max_elements(list1, N))

```

### print Max (or) Min value by using in-built Method::

```ruby

lis = [2, 4,1, 5,3,8,9] 
lis.sort() 
print("max = ", lis[-1], " min = ", lis[0])

```

### sorting a List ::


```ruby


list = [1, 3, 123, 1, 42, 123] # RANDOM NUMBERS
list.sort()
print(list)



(or)



my_list = [-15, -26, 15, 1, 23, -64, 23, 76]
new_list = []

while my_list:
min = my_list[0]  
for x in my_list: 
if x < min:
min = x
new_list.append(min)
my_list.remove(min)    

print(new_list)


```

### Ascending  (or ) Descending order of list


### Ascending 

```ruby

NumList = [12,45,87,49,56,46]
NumList.sort()
print("\nElement Before Sorting is: ", NumList)


(or)

list = [1,2,3,4,5,6,7]
list.sort()
print(list)



```


### Descendinng
```ruby



NumList = [12,45,87,49,56,46]
print("\nElement Before Sorting is: ", NumList)
NumList.sort()
NumList.reverse()
print("\nElement After Sorting List in Descending Order is: \n", NumList)



(or)




list = [1,2,3,4,5,6,7]
list.sort(reverse = True)
print(list)

```

### List of avarage numbers



```ruby


n=int(input("Enter the number of elements to be inserted: "))
a=[]
for i in range(0,n):
 elem=int(input("Enter element: "))
a.append(elem)
avg=sum(a)/n
print("Average of elements in the list",round(avg,2))


```

### Reverese a Nested list

```ruby

my_list=[[1,2],[3,4],[5,6,7]]
for sub_list in my_list:
  sub_list.reverse()
print(my_list)


```


### creating a list by using lambda function:


```ruby

m = [(lambda x:x)(x) for x in [1,2,3,4,54,5,6]]
print(m)



(or)


m = [(lambda x:x)(x) for x in range(10)]
print(m)

```






















