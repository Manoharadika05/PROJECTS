### 1. What do you understand by RESTful Web Services?
* RESTful web services are services that follow REST architecture.
* REST stands for Representational State Transfer and uses HTTP protocol (web protocol) for implementation.
* These services are lightweight, provide maintainability, scalability, support communication among multiple applications that are developed using different programming languages.
* They provide means of accessing resources present at server required for the client via the web browser by means of request headers, request body, response body, status codes, etc.

### 2. What is a REST Resource?
* Every content in the REST architecture is considered a resource. The resource is analogous to the object in the object-oriented programming world. 
* They can either be represented as text files, HTML pages, images, or any other dynamic data.
* The REST Server provides access to these resources whereas the REST client consumes (accesses and modifies) these resources. 
* Every resource is identified globally by means of a URI.

###  What is URI?
* Uniform Resource Identifier is the full form of URI which is used for identifying each resource of the REST architecture.
* URI is of the format:

```ruby

<protocol>://<service-name>/<ResourceType>/<ResourceID>
```
  
There are 2 types of URI:
  
  ![image](https://user-images.githubusercontent.com/100589467/172381108-a04ae6e0-e155-4ea7-80a5-816781077359.png)

**URN**: Uniform Resource Name identifies the resource by means of a name that is both unique and persistent.
* URN doesn’t always specify where to locate the resource on the internet. They are used as templates that are used by other parsers to identify the resource.
* These follow the urn scheme and usually prefixed with urn:. Examples include
*  **urn:isbn:1234567890** is used for identification of book based on the ISBN number in a library application.
*  **urn:mpeg:mpeg7:schema:2001** is the default namespace rules for metadata of MPEG-7 video.
* Whenever a URN identifies a document, they are easily translated into a URL by using “resolver” after which the document can be downloaded.

**URL:**
* Uniform Resource Locator has the information regarding fetching of a resource from its location.

**Examples include:**

* **http://abc.com/samplePage.html**
* **ftp://sampleServer.com/sampleFile.zip**
* **file:///home/interviewbit/sampleFile.txt**
* URLs start with a protocol (like ftp, http etc) and they have the information of the network hostname (sampleServer.com) and the path to the document(/samplePage.html).
* It can also have query parameters.
* ![image](https://user-images.githubusercontent.com/100589467/172384689-d3456997-7910-4b0e-8219-c09226bc33e6.png)

### 4. What are the features of RESTful Web Services?
* Every RESTful web service has the following features:
* The service is based on the Client-Server model.
* The service uses HTTP Protocol for fetching data/resources, query execution, or any other functions.
* The medium of communication between the client and server is called “Messaging”.
* Resources are accessible to the service by means of URIs.
* It follows the statelessness concept where the client request and response are not dependent on others and thereby provides total assurance of getting the required data.
* These services also use the concept of caching to minimize the server calls for the same type of repeated requests.
* These services can also use SOAP services as implementation protocol to REST architectural pattern.

### 5. What is the concept of statelessness in REST?
* The REST architecture is designed in such a way that the client state is not maintained on the server. 
* This is known as statelessness. The context is provided by the client to the server using which the server processes the client’s request. 
* The session on the server is identified by the session identifier sent by the client.

![image](https://user-images.githubusercontent.com/100589467/172385403-c3a7ec6c-ae9b-47bc-9107-0b04139239cc.png)


### 6. What do you understand by JAX-RS?
* As the name itself stands (JAX-RS= Java API for RESTful Web Services) is a Java-based specification defined by JEE for the implementation of RESTful services. 
* The JAX-RS library makes usage of annotations from Java 5 onwards to simplify the process of web services development. 
* The latest version is 3.0 which was released in June 2020. This specification also provides necessary support to create REST clients.

### 7. What are HTTP Status codes?
* These are the standard codes that refer to the predefined status of the task at the server. 
* Following are the status codes formats available:

* 1xx - represents informational responses
* 2xx - represents successful responses
* 3xx - represents redirects
* 4xx - represents client errors
* 5xx - represents server errors

**Most commonly used status codes are:**

* 200 - success/OK
* 201 - CREATED - used in POST or PUT methods.
* 304 - NOT MODIFIED - used in conditional GET requests to reduce the bandwidth use of the network. Here, the body of the response sent should be empty.
* 400 - BAD REQUEST - This can be due to validation errors or missing input data.
* 401- UNAUTHORIZED - This is returned when there is no valid authentication credentials sent along with the request.
* 403 - FORBIDDEN - sent when the user does not have access (or is forbidden) to the resource.
* 404 - NOT FOUND - Resource method is not available.
* 500 - INTERNAL SERVER ERROR - server threw some exceptions while running the method.
* 502 - BAD GATEWAY - Server was not able to get the response from another upstream server.

### 8. What are the HTTP Methods?
* HTTP Methods are also known as HTTP Verbs. They form a major portion of uniform interface restriction followed by the REST that specifies what action has to be followed to get the requested resource. Below are some examples of HTTP Methods:

* **GET:** This is used for fetching details from the server and is basically a read-only operation.
* **POST:** This method is used for the creation of new resources on the server.
* **PUT:** This method is used to update the old/existing resource on the server or to replace the resource.
* **DELETE:** This method is used to delete the resource on the server.
* **PATCH:** This is used for modifying the resource on the server.
* **OPTIONS:** This fetches the list of supported options of resources present on the server.
* The POST, GET, PUT, DELETE corresponds to the create, read, update, delete operations which are most commonly called CRUD 


* **Operations.**


![image](https://user-images.githubusercontent.com/100589467/172389178-0ed855aa-ed45-4bf8-9ebf-fb5100a74fdd.png)

GET, HEAD, OPTIONS are safe and idempotent methods whereas PUT and DELETE methods are only idempotent. POST and PATCH methods are neither safe nor idempotent.

### 9. Can you tell the disadvantages of RESTful web services?
**The disadvantages are:**
* As the services follow the idea of statelessness, it is not possible to maintain sessions. (Session simulation responsibility lies on the client-side to pass the session id)
* REST does not impose security restrictions inherently. It inherits the security measures of the protocols implementing it. Hence, care must be chosen to implement security measures like integrating SSL/TLS based authentications, etc.


### 10. Define Messaging in terms of RESTful web services.

* The technique of sending a message from the REST client to the REST server in the form of an HTTP request and the server responding back with the response as HTTP Response is called Messaging. 
* The messages contained constitute the data and the metadata about the message.


![image](https://user-images.githubusercontent.com/100589467/172392136-7c85b787-0d4d-4d57-b766-e1f5e25ec8f0.png)


### 11. Differentiate between SOAP and REST?

**SOAP**

* SOAP - Simple Object Access Protocol 
* SOAP is a protocol used to implement web services.
* SOAP cannot use REST as it is a protocol.
* SOAP specifies standards that are meant to be followed strictly.
* SOAP client is more tightly coupled to the server which is similar to desktop applications having strict contracts.
* SOAP supports only XML transmission between the client and the server.
* SOAP reads are not cacheable.
* SOAP reads are not cacheable.
* SOAP is slower.
* Since SOAP is a protocol, it defines its own security measures.
* SOAP is not commonly preferred, but they are used in cases which require stateful data transfer and more reliability.


**REST**

* REST - Representational State Transfer
* REST is an architectural design pattern for developing web services
* REST architecture can have SOAP protocol as part of the implementation.
* REST defines standards but they need not be strictly followed.
* The REST client is more flexible like a browser and does not depend on how the server is developed unless it follows the protocols required for establishing communication.
* REST supports data of multiple formats like XML, JSON, MIME, Text, etc.
* REST read requests can be cached.
* REST uses URI to expose the resource logic.
* REST is faster.
* REST only inherits the security measures based on what protocol it uses for the implementation.
* REST is commonly preferred by developers these days as it provides more scalability and maintainability.


### 12. While creating URI for web services, what are the best practices that needs to be followed?
* Below is the list of best practices that need to be considered with designing URI for web services:

* While defining resources, use plural nouns. Example: To identify user resource, use the name “users” for that resource.
* While using the long name for resources, use underscore or hyphen. Avoid using spaces between words. For example, to define authorized users resource, the name can be “authorized_users” or “authorized-users”.
* The URI is case-insensitive, but as part of best practice, it is recommended to use lower case only.
* While developing URI, the backward compatibility must be maintained once it gets published. When the URI is updated, the older URI must be redirected to the new one using the HTTP status code 300.
* Use appropriate HTTP methods like GET, PUT, DELETE, PATCH, etc. It is not needed or recommended to use these method names in the URI. Example: To get user details of a particular ID, use **/users/{id}** instead of **/getUser**
* Use the technique of forward slashing to indicate the hierarchy between the resources and the collections. Example: To get the address of the user of a particular id, we can use:**/users/{id}/address**

### 13.What are the differences between REST and AJAX?

**REST**
* REST- Representational State Transfer 
* REST has a URI for accessing resources by means of a request-response pattern.
* REST is an architectural pattern for developing client-server communication systems.
* REST requires the interaction between client and server.

**AJAX**

* AJAX - Asynchronous javascript and XML
* AJAX uses XMLHttpRequest object to send requests to the server and the response is interpreted by the Javascript code dynamically.
* AJAX is used for dynamic updation of UI without the need to reload the page.
* AJAX supports asynchronous requests thereby eliminating the necessity of constant client-server interaction.


### 14.Can you tell what constitutes the core components of HTTP Request?
* In REST, any HTTP Request has 5 main components, they are:

* Method/Verb − This part tells what methods the request operation represents. Methods like GET, PUT, POST, DELETE, etc are some examples.
* URI − This part is used for uniquely identifying the resources on the server.
* HTTP Version − This part indicates what version of HTTP protocol you are using. An example can be HTTP v1.1.
* Request Header − This part has the details of the request metadata such as client type, the content format supported, message format, cache settings, etc.
* Request Body − This part represents the actual message content to be sent to the server.


![image](https://user-images.githubusercontent.com/100589467/172397790-40011ae4-5fd8-4558-82b1-212a486d86b2.png)


### 15.What constitutes the core components of HTTP Response?
* HTTP Response has 4 components:

* Response Status Code − This represents the server response status code for the requested resource. Example- 400 represents a client-side error, 200 represents a successful response.
* HTTP Version − Indicates the HTTP protocol version.
* Response Header − This part has the metadata of the response message. Data can describe what is the content length, content type, response date, what is server type, etc.
* Response Body − This part contains what is the actual resource/message returned from the server.

![image](https://user-images.githubusercontent.com/100589467/172398127-dfba055d-e562-4c25-acc1-7e915543fd04.png)


### 16.Define Addressing in terms of RESTful Web Services.
* Addressing is the process of locating a single/multiple resources that are present on the server. 
* This task is accomplished by making use of URI (Uniform Resource Identifier). 
* The general format of URI is 
```ruby

<protocol>://<application-name>/<type-of-resource>/<id-of-resource>

```

### 17. What makes REST services to be easily scalable?
* REST services follow the concept of statelessness which essentially means no storing of any data across the requests on the server. 
* This makes it easier to scale horizontally because the servers need not communicate much with each other while serving requests

### 18.We can develop webservices using web sockets as well as REST. What are the differences between these two?


**REST**

* REST follows stateless architecture, meaning it won’t store any session-based data.
* The mode of communication is uni-directional. At a time, only the server or the client will communicate.
* The mode of communication is uni-directional. At a time, only the server or the client will communicate.
* Every request will have sections like header, title, body, URL, etc.
* For every HTTP request, a new TCP connection is set up.
* REST web services support both vertical and horizontal scaling.
* REST depends on HTTP methods to get the response.
* Communication is slower here.
* Memory/Buffers are not needed to store data here.

**Web Socket**

* Web Socket APIs follow the stateful protocol as it necessitates session-based data storage.
* The communication is bi-directional, communication can be done by both client or server at a time.
* Web Socket follows the full-duplex model.
* Web sockets do not have any overhead and hence suited for real-time communication.
* There will be only one TCP connection and then the client and server can start communicating.
* Web socket-based services only support vertical scaling.
* Web Sockets depend on the IP address and port number of the system to get a response.
* Message transmission happens very faster than REST API.
* Memory is required to store data.

**The request flow difference between the REST and Web Socket is shown below:**

![image](https://user-images.githubusercontent.com/100589467/172410409-46a7ef0d-adb5-4ecb-83ff-231070850beb.png)

### 19.Can we implement transport layer security (TLS) in REST?
* Yes, we can. TLS does the task of encrypting the communication between the REST client and the server and provides the means to authenticate the server to the client. It is used for secure communication as it is the successor of the Secure Socket Layer (SSL). HTTPS works well with both TLS and SSL thereby making it effective while implementing RESTful web services. One point to mention here is, the REST inherits the property of the protocol it implements. So security measures are dependent on the protocol REST implements.

### 20.Should we make the resources thread safe explicitly if they are made to share across multiple clients?
* There is no need to explicitly making the resources thread-safe because, upon every request, new resource instances are created which makes them thread-safe by default

### 21.What is Payload in terms of RESTful web services?
* Payload refers to the data passes in the request body. It is not the same as the request parameters. The payload can be sent only in POST methods as part of the request body.

### 22.Is it possible to send payload in the GET and DELETE methods?
* No, the payload is not the same as the request parameters. Hence, it is not possible to send payload data in these methods.

### 23.How can you test RESTful Web Services?
* RESTful web services can be tested using various tools like Postman, Swagger, etc. Postman provides a lot of features like sending requests to endpoints and show the response which can be converted to JSON or XML and also provides features to inspect request parameters like headers, query parameters, and also the response headers. Swagger also provides similar features like Postman and it provides the facility of documentation of the endpoints too. We can also use tools like Jmeter for performance and load testing of APIs

### 24. What is the maximum payload size that can be sent in POST methods?
* Theoretically, there is no restriction on the size of the payload that can be sent. But one must remember that the greater the size of the payload, the larger would be the bandwidth consumption and time taken to process the request that can impact the server performance.

### 25.How does HTTP Basic Authentication work?
* While implementing Basic Authentication as part of APIs, the user must provide the username and password which is then concatenated by the browser in the form of “username: password” and then perform base64 encoding on it. The encoded value is then sent as the value for the “Authorization” header on every HTTP request from the browser. Since the credentials are only encoded, it is advised to use this form when requests are sent over HTTPS as they are not secure and can be intercepted by anyone if secure protocols are not used.

### 26. What is the difference between idempotent and safe HTTP methods?
* Safe methods are those that do not change any resources internally. These methods can be cached and can be retrieved without any effects on the resource.
* Idempotent methods are those methods that do not change the responses to the resources externally. They can be called multiple times without any change in the responses.
According to restcookbook.com, the following is the table that describes what methods are idempotent and what is safe.

|---------------|-----------------|----------------|
|HTTP Methods   |    Idempotent  |	 	Safe       |
|---------------|-----------------|----------------|
|OPTIONS	 |     yes	            |    yes       |
|GET	     |    yes               | 	yes        |
|HEAD	   |   yes	              |  yes           |
|PUT	     |      yes	            |    no        |
|POST	   |     no               | 	no           |
|DELETE	 |     yes              | 	no           |
|PATCH	   |     no	              |  no          |
|---------|-----------------------|--------------|

### 27.What are the key features provided by JAX-RS API in Java EE?
* JAX-RS stands for Java API for RESTful Web services. They are nothing but a set of Java-based APIs that are provided in the Java EE which is useful in the implementation and development of RESTful web services.

**Features of JAX-RS are:**

* **POJO-based:** The APIs in the JAX-RS is based on a certain set of annotations, classes, and interfaces that are used with POJO (Plain Old Java Object) to expose the services as web services.
* **HTTP-based:** The JAX-RS APIs are designed using HTTP as their base protocol. They support the HTTP usage patterns and they provide the corresponding mapping between the HTTP actions and the API classes.
* **Format Independent:** They can be used to work with a wide range of data types that are supported by the HTTP body content.
* **Container Independent:** The APIs can be deployed in the Java EE container or a servlet container such as Tomcat or they can also be plugged into JAX-WS (Java API for XML-based web services) providers.


### 28.Define RESTful Root Resource Classes in the JAX-RS API?
* A resource class is nothing but a Java class that uses JAX-RS provided annotations for implementing web resources.
* They are the POJOs that are annotated either with @Path or have at least one method annotated with @Path, @GET, @POST, @DELETE, @PUT, etc.

**Example:**

```ruby

import javax.ws.rs.Path;
/**
* InterviewBitService is a root resource class that is exposed at 'resource_service' path
*/
@Path('resource_service')
public class InterviewBitService {
   // Defined methods
}

```

### 29.What do you understand by request method designator annotations?
* They are the runtime annotations in the JAX-RS library that are applied to Java methods. They correspond to the HTTP request methods that the clients want to make. They are @GET, @POST, @PUT, @DELETE, @HEAD.

**Usage Example:**

```ruby

import javax.ws.rs.Path;
/**
* InterviewBitService is a root resource class that is exposed at 'resource_service' path
*/
@Path('resource_service')
public class InterviewBitService {
    @GET
    public String getRESTQuestions() {
        // some operations
    } 
}

```

### 30.How can the JAX-RS applications be configured?
* JAX-RS applications have the root resource classes packaged in a war file. There are 2 means of configuring JAX-RS applications.

* Use @ApplicationPath annotation in a subclass of **javax.ws.rs.core.Application** that is packaged in the WAR file.
* Use the ```ruby <servlet-mapping>``` tag inside the web.xml of the WAR. web.xml is the deployment descriptor of the application where the mappings to the servlets can be defined.

### 31. List the key annotations that are present in the JAX-RS API?
**@Path** - This specifies the relative URI path to the REST resource.
**@GET** - This is a request method designator which is corresponding to the HTTP GET requests. They process GET requests.
**@POST** - This is a request method designator which is corresponding to the HTTP POST requests. They process POST requests.
**@PUT** - This is a request method designator which is corresponding to the HTTP PUT requests. They process PUT requests.
**@DELETE** - This is a request method designator which is corresponding to the HTTP DELETE requests. They process DELETE requests.
**@HEAD** - This is a request method designator which is corresponding to the HTTP HEAD requests. They process HEAD requests.
**@PathParam** - This is the URI path parameter that helps developers to extract the parameters from the URI and use them in the resource class/methods.
**@QueryParam** - This is the URI query parameter that helps developers extract the query parameters from the URI and use them in the resource class/methods.
**@Produces** - This specifies what MIME media types of the resource representations are produced and sent to the client as a response.
**@Consumes** - This specifies which MIME media types of the resource representations are accepted or consumed by the server from the client.

### 32.Define RestTemplate in Spring.
* The RestTemplate is the main class meant for the client-side access for Spring-based RESTful services. The communication to the server is accomplished using the REST constraints. This is similar to other template classes such as JdbcTemplate, HibernateTemplate, etc provided by Spring. The RestTemplate provides high-level implementation details for the HTTP Methods like GET, POST, PUT, etc, and gives the methods to communicate using the URI template, URI path params, request/response types, request object, etc as part of arguments.

* Commonly used annotations like **@GetMapping, @PostMapping, @PutMapping,** etc are provided by this class from Spring 4.3. Prior to that, Spring provided (and still provides) **@RequestMapping** annotation to indicate what methods were being used.

### 33.What does the annotation @PathVariable do?
* @PathVariable annotation is used for passing the parameter with the URL that is required to get the data. Spring MVC provides support for URL customization for data retrieval using @PathVariable annotation.

### 34.Is it necessary to keep Spring MVC in the classpath for developing RESTful web services?
* Yes. Spring MVC needs to be on the classpath of the application while developing RESTful web services using Spring. This is because, the Spring MVC provides the necessary annotations like @RestController, @RequestBody, @PathVariable, etc. Hence the spring-mvc.jar needs to be on the classpath or the corresponding Maven entry in the pom.xml

### 35.Define HttpMessageConverter in terms of Spring REST?
* HttpMessageConverter is a strategic interface that specified a converter for conversion between HTTP Requests and responses. Spring REST uses the HttpMessageConverter for converting responses to various data formats like JSON, XML, etc. Spring makes use of the “Accept” header for determining the type of content the client expects. Based on this, Spring would find the registered message converter interface that is capable of this conversion

































