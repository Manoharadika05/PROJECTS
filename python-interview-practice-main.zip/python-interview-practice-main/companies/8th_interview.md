### 1. what is Csrf token ?
### 2. built in data types ?
### 3. decorators ?
### 4. difference Between migrations and migrate ?
### 5. what is middleware in Django ?
### 6. a = [1,2,3,4,5,6] print 6 is equal to add of two values ?

```ruby
a = [1,2,3,4,5,6] 
6 = (4,2),(5,1)add this to print 6=6 like

```
### 7. Django Query ?
### 8. custom Exeption ?
### 9. custom middlewares ?

