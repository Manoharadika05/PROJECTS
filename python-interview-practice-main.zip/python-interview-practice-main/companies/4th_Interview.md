### 1.string split and convert to list and print the required string

```rubby 
Ex::name = 'manohar is a bad boy'

output like = 'manohar bad boy'
output llike = 'is a bad boy'

```
### 2. Nested Dictionary?
### 3. paramitarized function ?
### 4. what is an object ?
### 5. what is class ?
### 6. what is function ?
### 7. status codes in rest API?
### 8. what is django architecture ?
### 9. what are the Views ?
### 10. Http methods ?
### 11. what is a model ?

