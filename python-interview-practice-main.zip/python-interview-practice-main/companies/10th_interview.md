### 1. what django ?
### 2. what is Http and TCP ?
### 4. what is microservices ?
### 5. what is authentication where it use in your project ?
### 6. Hash Map ?
### 7. what is RestAPI ?
### 8. password where stored in once login ?
### 9. what is decorator ?
### 10. HTTP methods ?
### 11. Difference between get and post ?
### 12. "mano/reddy/mama/ : buddy/nanna/amma" team are saparated by  ":" and print the saparate team 1,team 2 and print team 1 ,team 2 saparate and print team size also ?
### 13. what is monolithic ?
