### 1. merge two dictionaries ?
### 2. "Omna12@#ahs!" saparate the strings ,speacial characters and Number ?count the saparately each one ?
### 3. decarators ?
### 4. Operator Overloading ?
### 5. docstring ?
### 6. Meta class ?
### 7. views ?
### 8. django Architecture ?
### 9. middlewares ?
### 10. Migrations ?
### 11. what many types of migrations ?
### 12. what are built_in data types ?
### 13. Django project Structure ?
### 14. what is init ?
### 15. With statement ? openwith statement ?
### 16. difference between Array and List ?
### 17. Genarator ?
### 18. python Memory management ?
### 19. what is Init ?
### 20. what is session ?
### 21. what is cookies ?
### 22. what is render function ?
### 23. what is map and filter ?
### 24. what is test.py ?
### 25. what is csrf Tiken?
