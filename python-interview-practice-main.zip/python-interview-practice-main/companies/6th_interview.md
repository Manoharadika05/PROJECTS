### 1. what is SDCL ?
### 2. what is Jenkins ? and Jenkins pipe line ?
### 3. Time complexity and space complexity ?
### 4. Add two numbers without "+" operator ?
### 5. How do take about the sutuation ?
### 6. Summery of  a project ?
