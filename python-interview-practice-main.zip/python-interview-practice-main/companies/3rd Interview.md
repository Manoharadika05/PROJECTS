### 1. What type of methodology your using ?
### 2. method overing concept ?
### 3. Print reverse order of sub list items ?
### 4. what is decorator ?
### 5. what is ORM in Django ?
### 6. what is MRO ?
### 7. Unitesting ?
### 8. Difference between Tuple and list ?
### 9. Django request and response life Cycle ?
### 10. what is middleware in Django ?
### 11. what is  middleware  order execution ?
### 12. what custom Authentication ?
