### 1. Merge arrays ?sort marged array?print Descending order ?

### 2. print in_built data types ?
