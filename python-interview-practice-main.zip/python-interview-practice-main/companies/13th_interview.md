### 1. what is decorator ?
### 2. what is MRO ?
### 3. what inheritance?
### 4. exeption ?
### 5. about overall project ?
