### 1. Types of views ? which type of views are using in your project ?
### 2. Django architecture ?
### 3. whare we impliment the business logic ?
### 4. sql queries are supported for django or not ?
### 5. how models to be connected with database ?
### 6. what is middleware ?
### 7. Two Databases are support for django simultaniously ?
### 8. what is virtual machine ?
### 9. what is next() ?
### 10. what is itration ?
### 11. what is Decorator ?
### 12. what is genarator ?Ex ?
### 13. what is append and extend ?
