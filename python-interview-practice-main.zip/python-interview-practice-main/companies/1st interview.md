### 1. Print N largest numbers in a list ?
### 2. How revert a dictionary ?
### 3. what is data abstraction ?
### 4. what is polymorphism ?
### 5. what is decorators ?
### 6. Difference between the migrations and migrate ?
### 7. Difference between Tuple and list ?
