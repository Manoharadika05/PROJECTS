### 1. what is Django ?
### 2. Middlewares ?
### 3. ORM ?
### 4. Django form fields ?
### 5. what are Http methos ?
### 6. what is rest API ?
### 7. difference between list and Tuple ?
### 8. what are Django forms ?
### 9. what is Serializers ?
### 10. possible to create django manage.py commands ?
### 11. how to integrate Rest API with Django ?
### 12. Unittesting ?
### 13. 
