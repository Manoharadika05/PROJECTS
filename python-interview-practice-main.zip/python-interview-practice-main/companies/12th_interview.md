### 1. input is "abcdefgh" expected outputis "AbcdEfGh" ?
### 2. mobile number validation ?
### 3. decorators with example ?
