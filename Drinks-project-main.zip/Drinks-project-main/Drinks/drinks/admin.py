from .models import Drink
from django.contrib import admin

admin.site.register(Drink)
