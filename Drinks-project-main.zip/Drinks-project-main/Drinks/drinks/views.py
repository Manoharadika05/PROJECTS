from django.http import JsonResponse
from .models import Drink
from .serializers import DrinkSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status

@api_view(['GET', 'POST'])
def drink_list(request, format=None):
    if request.method == "GET":
        # Get all the drinks, seirialize them and return json
        drinks = Drink.objects.all()
        serializer = DrinkSerializer(drinks, many=True)
        res = {'message': {'code' : '200', 'type': 'Ok', 'description': 'Resource retrived successfuly'},
                          'drink_details': serializer.data}

        return Response(res)

    if request.method == "POST":
        serializer = DrinkSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            add = {'message': {'code' : '201', 'type': 'Created', 'description': 'Resource created successfuly'},
                              'drink_details': serializer.data}
            return Response(add)


@api_view(['GET', 'PUT', 'DELETE'])
def drink_detail(request, id, format=None):
    try:
        drink = Drink.objects.get(pk=id)
    except Drink.DoesNotExist:
        return Response({'code': '400', 'type': 'BAD_REQUEST', 'description': 'Resource not found' })

    if request.method == "GET":
        serializer = DrinkSerializer(drink)

        res = {'message': {'code' : '200', 'type': 'Ok', 'description': 'Resource retrived successfuly'},
                      'drink_details': serializer.data}

        return Response(res)

    elif request.method == "PUT":
         serializer = DrinkSerializer(drink, data=request.data)
         if serializer.is_valid():
             serializer.save()
             upd = {'message': {'code' : '200', 'type': 'ok', 'description': 'Resource updated successfuly'},
                               'drink_details': serializer.data}

             return Response(upd)
         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    elif request.method == "DELETE":
         drink.delete()
         return Response({'code': '200', 'type': 'Ok', 'description': 'Resource deleted successfully' })
