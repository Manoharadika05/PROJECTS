package com.in28minutes.springboot.mybatis.h2.example.student;

public record Student(Long id,
                      String name,
                      String passport) {

}
