package com.in28minutes.springboot.rest.example.versioning;

public record StudentV2(Name name) {

}