package com.in28minutes.fullstack.springboot.fullstack.basic.authentication.springbootfullstackbasicauthloginlogout.course;

public record Course(Long id,
                     String username,
                     String description) {

}