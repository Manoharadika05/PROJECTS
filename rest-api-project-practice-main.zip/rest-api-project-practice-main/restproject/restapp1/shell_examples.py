from django.util.six import BytesIO
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONparsers
from django.core import serializers


from restapp1.api.serializers import restapp1serializer
from restapp1.models import restapp1

obj = restapp1.objects.first()
serializer = restapp1serializer(obj)
serializer.data


json_data = JSONRenderer().render(serializer.data)
print(data)

streame2 = BytesIO(json_data2)
data2   = JSONparsers().parse(streame2)
print(data2)



data = {'user':1}
serializer = restapp1serializer(data=data)

qs = restapp1.objects.all()
serializer2 = restapp1serializer(qs, many=True)
serializer2.data
json_data2 = JSONRenderer()render(serializer2.data)
print(json_data)


obj = restapp1.objects.first()
data = {'content' : 'some new content',"user":1}
update_serializer = restapp1serializer(obj, data=data)
update_serializer.is_valid()
update_serializer.save()




data = {"user":1,'content' : "please delete me"}
create_obj_serializer = restapp1serializer(data=data)
create_obj_serializer.is_valid()
create_obj = create_obj_serializer.save()
print(create_obj)


#data = {'id':9}
obj = restapp1.objects.last()
get_data_serializer = restapp1serializer(obj, data=data)
print(obj.delete())
#update_serializer.is_valid()
#update_serializer.save()

from rest_framework import serializers
class customserializer(serializers.serializer):
    text_field = serializer.charField()
    email      = serializers.EmailField()


data = {'email':'hello@gmail.com','content' : "please delete me"}
create_obj_serializer = customserializer(data=data)
if create_obj_serializer.is_valid()
    valid_data = create_obj_serializer.data
    print(valid_data)
