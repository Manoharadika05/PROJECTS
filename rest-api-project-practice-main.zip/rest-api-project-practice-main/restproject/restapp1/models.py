from django.db import models
from django.db import models
from django.conf import settings
from django.contrib.auth.models import User

# Create your models here.
def upload_restapp1_image(instance, filename):
    return "updates/{user}/{filename}.format(user=instance.user, filename=filename)"


class restapp1QuerySet(models.QuerySet):
    pass

class restapp1Manager(models.Manager):
    def get_queryset(self):
        return restapp1QuerySet(self.model, using=self._db)

class restapp1(models.Model):
    user            = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True)
    content         = models.TextField(max_length=300)
    image           = models.ImageField(upload_to=upload_restapp1_image)
    updated         = models.DateTimeField(auto_now=True)
    timestamp       = models.DateTimeField(auto_now_add=True)

    objects = restapp1Manager()


    def __str__(self):
        return str(self.content)[:50]

class Meta:
            verbose_name = 'restapp1 post'
            verbose_name_plural = 'restapp1 posts'
