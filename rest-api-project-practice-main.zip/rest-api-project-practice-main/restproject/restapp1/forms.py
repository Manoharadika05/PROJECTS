from django import forms

from .models import restapp1

class restapp1Form(forms.ModelForm):
    class Meta:
        models = restapp1
        fields = [
        'user',
        'content',
        'image',
        ]
    def clean_content(self, *args, **kwargs):
        content = self.cleaned_data.get('content')
        if len(content) > 240:
            raise forms.ValidationError("content is too long")
            return content

    def clean(self, *args, **kwargs):
        data = self.cleaned_data
        content = data.get('content',None)
        if content =="":
            content = None
        image = data.get("image",None)
        if content is None and image is None:
            raise forms.ValidationError('Content or image is required.')
        return super().clean(*args, **kwargs)
