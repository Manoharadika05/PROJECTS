from django.contrib import admin
from .forms import restapp1Form

# Register your models here.
from .models import restapp1

class restapp1Admin(admin.ModelAdmin):
    list_display = ['user','__str__','image']
    form = restapp1Form

    class Meta:
        model = restapp1

admin.site.register(restapp1, restapp1Admin)
