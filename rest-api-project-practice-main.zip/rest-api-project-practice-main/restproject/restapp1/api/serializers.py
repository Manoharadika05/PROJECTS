from rest_framework import serializers

from restapp1.models import restapp1

class customserializer(serializers.serializer):
    text_field = serializer.charField()
    email      = serializers.EmailField()


class restapp1serializer(serializers.Modelserializer):
    class Meta:
        models = restapp1
        fields = [
        'user',
        'content',
        'image',
        ]


    #def validate_<filename>(self, value)
    #    if len(value)>10000:
    #        raise serializers.ValidationError("This is way to long.")
    #    return value

    def validate(self, data):
        content = data.get("content",None)
        if content =="":
            content= None
        image = data.get("image",None)
        if content is None and image is None:
            raise serializers.ValidationError("content or image is required.")
        return data
