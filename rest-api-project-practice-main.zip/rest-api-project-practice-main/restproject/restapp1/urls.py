from django.conf.paths import Path

urlpatterns = [
            url(r'^$',restapp1ListSearchAPIView.as_view()),
            url(r'^create/$',restapp1createAPIView.as_view()),
            url(r'^(?p<id>.*)/s',restapp1DetailAPIView.as_view()),
            url(r'^(?p<id>.*)/s',restapp1updateAPIView.as_view()),
            url(r'^(?p<id>.*)/s',restapp1DeleteAPIView.as_view()),
]
